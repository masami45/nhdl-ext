# nhdl-button-replacer

Replace original nhentai download link with [nhdl link](https://nhdl2.herokuapp.com/).
This extension only active on `https://nhentai.net/g/*` and doesn't include any icon you can see.

### How to install?
1. clone the repo

for **Firefox**

2. access `about:debugging#/runtime/this-firefox`
3. click `Load Temporary Add-on...` and select the file inside `nhdl-button-replacer` folder
4. done!

for **Chrome**

2. access `chrome://extensions`
3. click `Load Unpacked` and select the `nhdl-button-replacer` folder
4. done!
